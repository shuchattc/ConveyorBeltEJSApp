const Cart = require('../models/cart');

module.exports.checkout = async (req, res) => {
  try {
    const userId = req.user._id;

    const cart = await Cart.findOne({ user: userId }).populate({
      path: 'order',
      populate: { path: 'items.food' }
    });

    if (!cart || !cart.order || cart.order.items.length === 0) {
      req.flash('error', 'Your cart is empty.');
      return res.redirect('/home');
    }

    res.render('checkout', { cart, order: cart.order });
  } catch (err) {
    console.error('Checkout error:', err);
    req.flash('error', 'Something went wrong during checkout.');
    res.redirect('/home');
  }
};

module.exports.completeCheckout = async (req, res, next) => {
  try {
    const userId = req.user._id;

    // Delete the user's cart
    await Cart.findOneAndDelete({ user: userId });

    // Log out the user
    req.logout(function(err) {
      if (err) return next(err);

      req.flash('success', 'Order completed and you have been logged out.');
      res.redirect('/');
    });

  } catch (err) {
    console.error('Error during checkout + logout:', err);
    req.flash('error', 'Something went wrong.');
    res.redirect('/home');
  }
};