const FoodItem = require('../models/foodItems'); 
const Order    = require('../models/orders');      // model, not schema
const Cart = require('../models/cart');
const User = require('../models/user');

module.exports.appetizers = async(req,res) => {
    const appetizers = await FoodItem.find({category:"appetizer"});
    res.render('menu/appetizers', {appetizers});
};

module.exports.sushi = async(req,res) =>{
    const sushi = await FoodItem.find({category: "sushi"});
    res.render('menu/sushi', {sushi});
};

module.exports.drink = async(req,res) =>{
    const drink = await FoodItem.find({category: "drink"});
    res.render('menu/drink', {drink});
};

module.exports.dessert = async(req,res) =>{
    const dessert = await FoodItem.find({category: "dessert"});
    res.render('menu/dessert', {dessert});
};

module.exports.renderNewForm = async(req,res) =>{ 
    res.render('menu/new');
};

module.exports.viewMenuItem = async(req,res) =>{ 
    const thisFoodItem = await FoodItem.findById(req.params.id);
    // console.log(thisFoodItem);
    res.render("menu/edit", {thisFoodItem});
};

module.exports.createNewItem = async(req,res) => {
    const newFood = new FoodItem(req.body.food);
    await newFood.save();
    // console.log(newFood);
    req.flash('success', 'Successfully made a new food item!');
    res.redirect(`/home`)
};

module.exports.editMenuItem = async(req,res) => {
    const {id} = req.params;
    const foodItem = await FoodItem.findByIdAndUpdate(id, {...req.body.FoodItem});
    req.flash('success', 'Successfully updated item');
    res.redirect('/home');
};

module.exports.deleteMenuItem = async(req,res) => {
    const { id } = req.params;
    await FoodItem.findByIdAndDelete(id);
    req.flash('success', 'Order sent.')
    res.redirect('/home');
};

module.exports.orderItem = async (req, res) => {
  try {
    const userId = req.user._id;
    const foodId = req.params.id;
    const qty = parseInt(req.body?.qty, 10) || 1;

    // Find user's cart
    let cart = await Cart.findOne({ user: userId }).populate({
      path: 'order',
      populate: { path: 'items.food' }
    });

    let order;

    if (!cart) {
      // CASE 1: No cart → create new order + cart
      const food = await FoodItem.findById(foodId);
      order = new Order({
        user: userId,
        items: [{ food: foodId, qty }],
        totalPrice: food.price * qty
      });
      await order.save();

      cart = new Cart({ user: userId, order: order._id });
      await cart.save();

    } else if (!cart.order) {
      // CASE 2: Cart exists, no order → create new order
      const food = await FoodItem.findById(foodId);
      order = new Order({
        user: userId,
        items: [{ food: foodId, qty }],
        totalPrice: food.price * qty
      });
      await order.save();

      cart.order = order._id;
      await cart.save();

    } else {
      // CASE 3: Cart and order exist → add/update item
      order = await Order.findById(cart.order._id).populate('items.food');

      const existingItem = order.items.find(
        (item) => item.food._id.toString() === foodId
      );

      if (existingItem) {
        existingItem.qty += qty;
      } else {
        order.items.push({ food: foodId, qty });
      }

      // Recalculate total safely
      order.totalPrice = order.items.reduce((sum, item) => {
        if (!item.food || typeof item.food.price !== 'number') return sum;
        return sum + item.qty * item.food.price;
      }, 0);

      await order.save();
    }

    req.flash('success', 'Order sent to kitchen.');
    res.redirect('/checkout');

  } catch (err) {
    console.error('OrderItem error:', err);
    req.flash('error', 'Something went wrong.');
    res.redirect('/home');
  }
};