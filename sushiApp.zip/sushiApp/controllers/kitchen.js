const Order = require('../models/orders');   // model, not schema
const FoodItem = require('../models/foodItems'); 

module.exports.getAllOrders = async(req,res) =>{ 
    const order = await Order.find({}).populate({path: 'items.food', select:'title price'});
    res.render('staff/kitchen', {order, messages: req.flash('success')});
};

module.exports.completeOrder = async(req,res) => {
    await Order.findByIdAndDelete(req.params.id);
    req.flash('success', 'Order deleted');
    res.redirect('/kitchen');
};