// cart.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const CartSchema = new Schema({
  user: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    unique: true // one active cart per user
  },
  order: {
    type: Schema.Types.ObjectId,
    ref: 'Order',
    required: false
  },   // use the subdocument schema
  createdAt: {
    type: Date,
    default: Date.now
  }
});


// Helper method to recalc total
CartSchema.methods.calculateTotal = async function () {
  await this.populate('items.food');
  this.totalPrice = this.items.reduce((sum, item) => {
    return sum + item.qty * item.food.price;
  }, 0);
  return this.totalPrice;
};

module.exports = mongoose.model('Cart', CartSchema);
