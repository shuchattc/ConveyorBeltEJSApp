const mongoose = require('mongoose');
const FoodItems = require('./foodItems');
const User = require('./user');
const Schema = mongoose.Schema;

const OrderSchema = new Schema({
  user: {
    type: Schema.Types.ObjectId,
    ref: 'User'
  },
  items: [{
    food: { type: Schema.Types.ObjectId, ref: 'FoodItem' },
    qty: { type: Number, default: 1 }
  }],
  totalPrice: {
    type: Number,
    default: 0
  },
  status: {
    type: String,
    enum: ['placed', 'completed', 'cancelled'],
    default: 'placed'
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});


module.exports = mongoose.model('Order', OrderSchema);