const express = require('express');
const router = express.Router();
const CatchAsync = require('../utils/catchAsync');
const Order = require('../models/orders');
const Cart = require('../models/cart');
const checkout = require('../controllers/checkout')


router.get('/', checkout.checkout);

router.post('/complete', checkout.completeCheckout);

module.exports = router;